from FortyTwo.fortytwo import *
def Start():
    """No Clue what to add here"""
