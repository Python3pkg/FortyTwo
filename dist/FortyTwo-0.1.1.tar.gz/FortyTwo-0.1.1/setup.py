from distutils.core import setup
setup(
  name = 'FortyTwo',
  packages = ['FortyTwo'], # this must be the same as the name above
  version = '0.1.1',
  description = "This is the module containing 1m0r74l17y's stuff.",
  author = '1m0r74l17y',
  author_email = 'tobiasdalaa@gmail.com',
  url = 'https://github.com/1m0r74l17y/FortyTwo', # use the URL to the github repo
  download_url = 'https://github.com/1m0r74l17y/FortyTwo/tarball/0.1.1', # I'll explain this in a second
  keywords = ['Life', 'Universe', 'Everything', '1m0r74l17y'], # arbitrary keywords
  classifiers = [],
)
