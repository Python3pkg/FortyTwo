
import FortyTwo

def Start():
