
import FortyTwo

def Start():
    """No Clue what to add here"""
